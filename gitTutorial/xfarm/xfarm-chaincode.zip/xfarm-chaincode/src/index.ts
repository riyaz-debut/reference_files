/*
 * SPDX-License-Identifier: Apache-2.0
 */

import {ChaincodeXFarmContract} from './chaincodeXFarm';

export {ChaincodeXFarmContract} from './chaincodeXFarm';

export const contracts: any[] = [ChaincodeXFarmContract];
